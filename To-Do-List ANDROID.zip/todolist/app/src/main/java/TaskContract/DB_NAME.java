package TaskContract;

public class DB_NAME {
}
