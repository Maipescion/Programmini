package TaskContract;

public class DB_VERSION {
}
