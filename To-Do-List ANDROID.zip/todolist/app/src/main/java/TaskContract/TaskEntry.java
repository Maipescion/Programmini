package TaskContract;

public class TaskEntry {
    private static String todolist;
    public static final String COL_TASK_TITLE = todolist;
    public static final String TABLE = todolist;
    public static final String _ID = todolist;
}
